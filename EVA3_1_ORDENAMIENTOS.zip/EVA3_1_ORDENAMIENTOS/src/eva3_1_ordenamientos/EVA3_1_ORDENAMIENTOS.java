package eva3_1_ordenamientos;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * @author Ernesto Domínguez Meléndez
 */
public class EVA3_1_ORDENAMIENTOS {

    public static void main(String[] args) {

        int[] datos = new int[20];
        llenar(datos);
        imprimir(datos);

        long start, finish;

        /* start = System.nanoTime();
        selectionSort(datos);
        finish = System.nanoTime();
        imprimir(datos);
        System.out.println("Tiempo de ejecución: " + (finish - start) + " nanosegundos");

        llenar(datos);
        imprimir(datos);

        start = System.nanoTime();
        insertionSort(datos);
        finish = System.nanoTime();
        imprimir(datos);
        System.out.println("Tiempo de ejecución: " + (finish - start) + " nanosegundos");

        llenar(datos);
        imprimir(datos);

        start = System.nanoTime();
        bubbleSort(datos);
        finish = System.nanoTime();
        imprimir(datos);
        System.out.println("Tiempo de ejecución: " + (finish - start) + " nanosegundos");
         */
        selectionSort(datos);
        imprimir(datos);

        Scanner scanner = new Scanner(System.in);
        int x = Integer.parseInt(JOptionPane.showInputDialog(null, "Valor a buscar"));

        System.out.println("Posición: " + busquedaBin(datos, x));

    }

    public static void llenar(int[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i] = (int) (Math.random() * 100);
        }
    }

    public static void imprimir(int[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print("[" + arreglo[i] + "]");
        }
        System.out.println("\n-------------");
    }

    // MAS COMPARACIONES, MENOS INTERCAMBIOS
    public static void selectionSort(int[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            int aux = i;
            for (int j = i + 1; j < arreglo.length - 1; j++) {
                if (arreglo[j] < arreglo[aux]) {
                    aux = j;
                }
            }
            int temp = arreglo[i];
            arreglo[i] = arreglo[aux];
            arreglo[aux] = temp;
        }
    }

    // MAS INTERCAMBIOS, MENOS COMPARACIONES
    public static void insertionSort(int[] arreglo) {
        for (int i = 1; i < arreglo.length; i++) {
            int temp = arreglo[i];
            for (int insertionPoint = i; insertionPoint > 0; insertionPoint--) {
                int prev = insertionPoint - 1;
                if (arreglo[prev] > temp) {
                    arreglo[insertionPoint] = arreglo[prev];
                } else {
                    break;
                }
                arreglo[insertionPoint] = temp;
            }
        }
    }

    public static void bubbleSortQuestionMark(int[] array) {
        for (int j = 0; j < (array.length - 1); j++) {
            if (array[j] > array[j + 1]) {
                int aux = array[j];
                array[j] = array[j + 1];
                array[j + 1] = aux;
            }
        }
    }

    public static void bubbleSort(int[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            for (int j = 0; j < arreglo.length - 1; j++) {
                if (arreglo[j] > arreglo[j + 1]) {
                    int temp = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = temp;
                }
            }
        }
    }

    public static void quickSort(int[] arreglo) {
        quickSortRec(arreglo, 0, arreglo.length - 1);
    }

    private static void quickSortRec(int[] arreglo, int start, int finish) {
        if ((start < finish) && (start >= 0) && (finish < arreglo.length)) {
            int pivote = start;
            int too_big = start + 1;
            int too_small = finish;
            int aux = 0;
            while (too_big < too_small) {
                while ((too_big < pivote) && (arreglo[too_big]) < arreglo[pivote]) {
                    too_big++;
                }

                while ((too_small > (start + 1)) && (arreglo[too_small] > arreglo[pivote])) {
                    too_small--;
                }

                if (too_big < too_small) { // No se han cruzado
                    aux = arreglo[too_big];
                    arreglo[too_big] = arreglo[too_small];
                    arreglo[too_small] = aux;
                }
            }

            aux = arreglo[pivote];
            arreglo[pivote] = arreglo[too_small];
            arreglo[too_small] = aux;

            quickSortRec(arreglo, start, (too_small - 1)); // Izquierda
            quickSortRec(arreglo, (too_small + 1), finish); // Derecha
        }
    }

    public static int busquedaBin(int[] array, int x) {
        return busquedaBinRec(array, x, 0, array.length - 1);
    }

    private static int busquedaBinRec(int[] array, int x, int start, int finish) {
        if (start <= finish) {
            int mid = start + ((finish - start) / 2);

            if (x == array[mid]) {
                return mid;
            } else if (x > array[mid]) {
                return busquedaBinRec(array, x, (mid + 1), finish);
            } else {
                return busquedaBinRec(array, x, start, (mid - 1));
            }
        } else {
            return (-1);
        }
    }
}
