package eva3_2_comparator;

import java.util.Comparator;
import java.util.LinkedList;

/**
 * @author Ernesto Domínguez Meléndez
 */
public class EVA3_2_COMPARATOR {

    public static void main(String[] args) {

        LinkedList<Integer> list = new LinkedList<Integer>();

        list.add(6);
        list.add(9);
        list.add(8);
        list.add(7);
        list.add(10);
        list.add(5);
        list.add(4);
        list.add(2);
        list.add(3);
        list.add(1);

        System.out.println(list);

        Comparator c = new Comparator() { // Se define una clase anónima (No tiene nombre) // Se está creando una clase y un objeto al mismo tiempo
            @Override
            public int compare(Object t, Object t1) {
                int result = 0;

                // Cero = igual
                // Positivo = mayor
                // Negativo = menor
                Integer x, y;
                x = (Integer) t;
                y = (Integer) t1;
                result = x - y;
                return result;
            }

        };

        list.sort(c);
        System.out.println(list);

        LinkedList<String> stringList = new LinkedList<String>();

        stringList.add("Hola");
        stringList.add(" ");
        stringList.add("mundo");
        stringList.add(" ");
        stringList.add("cruel");
        stringList.add(" ");
        stringList.add("!");

        Comparator compareString = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                String string1 = (String) o1;
                String string2 = (String) o2;

                char c1 = string1.charAt(0);
                char c2 = string2.charAt(0);

                return c1 - c2;
            }
        };

        System.out.println(stringList);
        stringList.sort(compareString);

        System.out.println(stringList);

    }

}
